#programa para resolver una ecuacion lineal

a = int (input("indique el valor a "))
b = int (input("indique el valor b "))
x = -1 * b/a

print ("el resultado de x es: ", x)