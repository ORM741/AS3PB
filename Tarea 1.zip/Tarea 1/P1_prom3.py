#programa para calcular el promedio de 3 numeros

N1 = float (input ("indique el primer numero "))
N2 = float (input ("indique el segundo numero "))
N3 = float (input ("indique el tercer numero "))

promedio = ( N1 + N2 + N3 )/3

print (promedio)