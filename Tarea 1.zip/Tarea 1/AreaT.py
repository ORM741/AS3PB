#calcular el area de un triangulo

H = float (input ("indique la base de un triangulo "))
B = float (input ("indique la altura de un triangulo "))
Area = (B * H)/2

print ("el area del triangulo es ", Area)