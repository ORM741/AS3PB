#calcular el area de un rectangulo

B = float (input ("indique el ancho de un rectangulo "))
H = float (input ("indique la altura de un rectangulo "))
Area = (B * H)
perimetro = 2 * (B + H )
print ("el area del rectangulo es ", Area , "y el perimetro es ", perimetro)