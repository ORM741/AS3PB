#programa para calcular el volumen de una esfera
r = float (input ("indique el radio de un circulo "))
pi = 3.14
area = 4 * pi * r**2
volumen = 3/4 * pi * r**3

print ("el area de la esfera es ", area , "y el volumen es", volumen)
