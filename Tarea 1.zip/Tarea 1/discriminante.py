#programa para calcular el discriminate de una ecuacion cuadratica

a = float (input ("indique el valor A de la ecuacion "))
b = float (input ("indique el valor B de la ecuacion "))
C = float (input ("indique el valor C de la ecuacion "))

discriminate = b**2 - 4 * a * c

print ("el discriminate de la ecuacion es ", discriminate)