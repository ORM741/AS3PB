#programa que calcula el resultado de una ecuacion

a = int (input("indique el valor a "))
b = int (input("indique el valor b "))
c = int (input("indique el valor c "))
d = int (input("indique el valor d "))
e = int (input("indique el valor e "))
res = (a+b) * (c-d) / e

print ("el resultado es ", res)