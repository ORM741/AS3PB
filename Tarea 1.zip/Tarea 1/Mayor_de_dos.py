#programa para determinar el meyor de dos numeros

N1 = float (input ("indique el primer numero "))
N2 = float (input ("indique el segundo numero "))

if N1 > N2 :
    print ("el numero ", N1 , "es mayor que el numero " , N2)
else :
    print ("el numero ", N2 , "es mayor que el numero " , N1)