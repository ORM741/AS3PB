#programa para calcular el area de un trapecio

b1 = float (input ("indique la base 1 del trapecio "))
b2 = float (input ("indique la base 2 del trapecio "))
h = float (input ("indique la altura del trapecio "))
area = ((b1 * b2) * h ) / 2

print ("el area del trapecio es ", area)