#programa para convertir horas a minutos 

horas = int (input ("indique las horas a convterir "))
min = horas * 60

print (horas ,"horas son ", min , "minutos")