# programa para convertir grados celcius a farenheit

c = float (input ("indique la cantidad a convertir "))
F = round (((9/5*c) + 32),3)
print ("el resultado de la convercion es " , F)