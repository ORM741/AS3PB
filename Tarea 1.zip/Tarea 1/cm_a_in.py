# programa para convertir centimetros a pulgadas

cm = float (input ("indique la cantidad a convertir "))
pul = round ((cm / 2.54),3)
print ("el resultado de la convercion es " , pul)