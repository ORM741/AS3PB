#calcular el area de un circulo
r = float (input ("indique el radio de un circulo "))
pi = 3.14
Area = ((r)**2) * pi 

print ("el area del circulo es ", Area)